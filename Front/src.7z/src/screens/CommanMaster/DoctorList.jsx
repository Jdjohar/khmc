import React from 'react'

const DoctorList = () => {
  return (
    <div>DoctorList</div>
  )
}

export default DoctorList