import React from 'react'

const DoseComment = () => {
  return (
    <div>DoseComment</div>
  )
}

export default DoseComment