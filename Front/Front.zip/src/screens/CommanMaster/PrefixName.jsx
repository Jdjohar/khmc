import React from 'react'
import Topbar from '../../component/TopNavBar'
import SideNavbar from '../../component/SideNavbar'

const PrefixName = () => {
  return (
    <>
      <Topbar />
      <div className="container-fluid page-body-wrapper">
        <SideNavbar />
        <div className="main-panel">
          <div className="content-wrapper">
            <div className="page-header">
              <h3 className="page-title">
                <span className="page-title-icon bg-gradient-primary text-white me-2">
                  <i className="mdi mdi-home"></i>
                </span>
                Name Prefix
              </h3>
              <nav aria-label="breadcrumb">
                <ul className="breadcrumb">
                  <li className="breadcrumb-item active" aria-current="page">
                    <span></span>Prefix <i className="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                  </li>
                </ul>
              </nav>
            </div>

            <div className="row">
              <div className="col-4 grid-margin stretch-card">
                <div className="card">
                  <div className="card-body">

                    <table class="table">
                      <thead>
                        <tr>
                          <th>State Name</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Jacob</td>
                          <td>53275531</td>

                        </tr>
                        <tr>
                          <td>Messsy</td>
                          <td>53275532</td>

                        </tr>
                        <tr>
                          <td>John</td>
                          <td>53275533</td>

                        </tr>
                        <tr>
                          <td>Peter</td>
                          <td>53275534</td>

                        </tr>
                        <tr>
                          <td>Dave</td>
                          <td>53275535</td>

                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div className="col-8 grid-margin stretch-card">
                <div className="card">
                  <div className="card-body">
                    <form className="forms-sample">
                      <div className="form-group row">
                        <div className="col-6 mt-3">
                          <label htmlFor="statename">Prefix Name </label>
                          <input type="text" className="form-control" id="statename" placeholder="Enter Prefix Name" />
                        </div>
                        <div className="col-6 mt-3">
                          <label htmlFor="statecode">Order </label>
                          <input type="text" className="form-control" id="statecode" placeholder="0" />
                        </div>
                        <div className="col-6 mt-3">
                          <label htmlFor="statecode">Use for</label>
                          <select
                            className="form-control"
                            id="usefor"


                          >
                            <option value="">Select Patient Type</option>
                            <option value="pathology">Pathology</option>
                            <option value="hospital">Hospital</option>
                          </select>
                        </div>

                      </div>
                      <button type="submit" className="btn btn-gradient-primary me-2">Submit</button>
                      <button className="btn btn-light">Cancel</button>
                    </form>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default PrefixName