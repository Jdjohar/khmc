import React from 'react';
import Topbar from '../../component/TopNavBar';
import SideNavbar from '../../component/SideNavbar';

const Department = () => {
  return (
    <>
      <Topbar />
      <div className="container-fluid page-body-wrapper">
        <SideNavbar />
        <div className="main-panel">
          <div className="content-wrapper">
            <div className="page-header">
              <h3 className="page-title">
                <span className="page-title-icon bg-gradient-primary text-white me-2">
                  <i className="mdi mdi-home"></i>
                </span>
                Department
              </h3>
              <nav aria-label="breadcrumb">
                <ul className="breadcrumb">
                  <li className="breadcrumb-item active" aria-current="page">
                    <span></span>Department <i className="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                  </li>
                </ul>
              </nav>
            </div>

            <div className="row">
              <div className="col-4 grid-margin stretch-card">
                <div className="card">
                  <div className="card-body">
                    <h4 className="card-title">Department List</h4>
                    <table className="table">
                      <thead>
                        <tr>
                          <th>Bank Name</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Jacob</td>
                          <td>53275531</td>
                        </tr>
                        <tr>
                          <td>Messsy</td>
                          <td>53275532</td>
                        </tr>
                        <tr>
                          <td>John</td>
                          <td>53275533</td>
                        </tr>
                        <tr>
                          <td>Peter</td>
                          <td>53275534</td>
                        </tr>
                        <tr>
                          <td>Dave</td>
                          <td>53275535</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              <div className="col-8 grid-margin stretch-card">
                <div className="card">
                  <div className="card-body">
                    <form className="forms-sample">
                      <div className="form-group row">
                        <div className="col-6 mt-3">
                          <label htmlFor="departmentname">Department Name</label>
                          <input
                            type="text"
                            className="form-control"
                            id="departmentname"
                            placeholder="Enter Department Name"
                          />
                        </div>

                        <div className="col-6 mt-3">
                          <label htmlFor="usefor">Use in</label>
                          <select className="form-control" id="usefor">
                            <option value="">Both</option>
                            <option value="indooronly">Indoor Only</option>
                            <option value="outdooronly">Outdoor Only</option>
                            <option value="directpatient">Direct Patient</option>
                          </select>
                        </div>

                        <div className="col-6 mt-3">
                          <label htmlFor="order">Order</label>
                          <input
                            type="text"
                            className="form-control"
                            id="order"
                            placeholder="0"
                          />
                        </div>

                        {/* Comment Field */}
                        <div className="col-12 mt-3">
                          <label htmlFor="comment">Comment</label>
                          <textarea
                            className="form-control"
                            id="comment"
                            placeholder="Enter your comment"
                            rows="4"
                          ></textarea>
                        </div>

                        {/* Department Investigating - Checkboxes */}
                        <div className="col-12 mt-3">
                          <label>Name of the Department Investigating</label>
                          <div className="form-check">
                            <input
                              type="checkbox"
                              className="form-check-input"
                              id="gyne"
                            />
                            <label className="form-check-label" htmlFor="gyne">
                              Gyne
                            </label>
                          </div>
                          <div className="form-check">
                            <input
                              type="checkbox"
                              className="form-check-input"
                              id="infertility"
                            />
                            <label className="form-check-label" htmlFor="infertility">
                              Infertility
                            </label>
                          </div>
                          <div className="form-check">
                            <input
                              type="checkbox"
                              className="form-check-input"
                              id="dental"
                            />
                            <label className="form-check-label" htmlFor="dental">
                              Dental
                            </label>
                          </div>
                          <div className="form-check">
                            <input
                              type="checkbox"
                              className="form-check-input"
                              id="radiology"
                            />
                            <label className="form-check-label" htmlFor="radiology">
                              Radiology
                            </label>
                          </div>
                          <div className="form-check">
                            <input
                              type="checkbox"
                              className="form-check-input"
                              id="eye"
                            />
                            <label className="form-check-label" htmlFor="eye">
                              Eye
                            </label>
                          </div>
                        </div>
                      </div>

                      <button type="submit" className="btn btn-gradient-primary me-2">
                        Submit
                      </button>
                      <button className="btn btn-light">Cancel</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Department;
