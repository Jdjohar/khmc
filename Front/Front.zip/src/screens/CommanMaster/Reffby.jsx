import React, { useState } from 'react';
import Topbar from '../../component/TopNavBar';
import SideNavbar from '../../component/SideNavbar';

const Reffby = () => {
  const [doctorType, setDoctorType] = useState('Doctor');
  const [doctorNameLabel, setDoctorNameLabel] = useState('Doctor Name');

  // Sample data for the table
  const doctorList = [
    { name: 'Dr. John Doe', type: 'Doctor', department: 'Department 1' },
    { name: 'Dr. Jane Smith', type: 'Pathologist', department: 'Department 2' },
    { name: 'Dr. Sam Wilson', type: 'Consultant', department: 'Department 3' }
  ];

  // Handle dynamic label based on the selected "Type"
  const handleTypeChange = (e) => {
    const selectedType = e.target.value;
    setDoctorType(selectedType);
    setDoctorNameLabel(selectedType + ' Name');
  };

  // Mobile number validation
  const handleMobileChange = (e) => {
    const value = e.target.value;
    const regex = /^[6-9]\d{9}$/;
    if (!regex.test(value)) {
      alert('Please enter a valid 10-digit Indian mobile number starting with 6-9.');
    }
  };

  // Email validation
  const handleEmailChange = (e) => {
    const value = e.target.value;
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!regex.test(value)) {
      alert('Please enter a valid email address.');
    }
  };

  return (
    <>
      <Topbar />
      <div className="container-fluid page-body-wrapper">
        <SideNavbar />
        <div className="main-panel">
          <div className="content-wrapper">
            <div className="page-header">
              <h3 className="page-title">
                <span className="page-title-icon bg-gradient-primary text-white me-2">
                  <i className="mdi mdi-home"></i>
                </span>
                Doctor
              </h3>
              <nav aria-label="breadcrumb">
                <ul className="breadcrumb">
                  <li className="breadcrumb-item active" aria-current="page">
                    <span></span>Doctor <i className="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                  </li>
                </ul>
              </nav>
            </div>

            <div className="row">
              {/* Doctor List Table */}
              <div className="col-4 grid-margin stretch-card">
                <div className="card">
                  <div className="card-body">
                    <h4 className="card-title">Doctor List</h4>
                    <table className="table">
                      <thead>
                        <tr>
                          <th>Doctor Name</th>
                          <th>Department</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        {doctorList.map((doctor, index) => (
                          <tr key={index}>
                            <td>{doctor.name}</td>
                          
                            <td>{doctor.department}</td>
                            
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Doctor Form */}
              <div className="col-8 grid-margin stretch-card">
                <div className="card">
                  <div className="card-body">
                    <form className="forms-sample">
                      <div className="row">
                        {/* Type */}
                        <div className="row">
  {/* Type */}
  <div className="col-6 form-group">
    <label htmlFor="type">Type</label>
    <select className="form-control" id="type" onChange={handleTypeChange}>
      <option value="Doctor">Doctor</option>
      <option value="Ref / Agent">Ref / Agent</option>
      <option value="Pathologist">Pathologist</option>
      <option value="Anesthist">Anesthist</option>
      <option value="OT Manager">OT Manager</option>
      <option value="OT Assistent">OT Assistent</option>
      <option value="Consultent">Consultent</option>
    </select>
  </div>

  {/* Doctor Name (dynamic label based on type) */}
  <div className="col-6 form-group">
    <label htmlFor="doctorName">{doctorNameLabel}</label>
    <input
      type="text"
      className="form-control"
      id="doctorName"
      placeholder={`Enter ${doctorNameLabel}`}
    />
  </div>

  {/* Department */}
  <div className="col-6 form-group">
    <label htmlFor="department">Department</label>
    <select className="form-control" id="department">
      <option value="department1">Department 1</option>
      <option value="department2">Department 2</option>
      <option value="department3">Department 3</option>
      <option value="department4">Department 4</option>
    </select>
  </div>

  {/* Status */}
  <div className="col-6 form-group">
    <label htmlFor="status">Status</label>
    <select className="form-control" id="status">
      <option value="active">Active</option>
      <option value="inactive">Inactive</option>
    </select>
  </div>

  {/* Address */}
  <div className="col-12 form-group">
    <label htmlFor="address">Address</label>
    <textarea
      className="form-control"
      id="address"
      rows="2"
      placeholder="Enter Address"
    ></textarea>
  </div>

  {/* City */}
  <div className="col-6 form-group">
    <label htmlFor="city">City</label>
    <input
      type="text"
      className="form-control"
      id="city"
      placeholder="Enter City"
    />
  </div>

  {/* Mobile Number */}
  <div className="col-6 form-group">
    <label htmlFor="mobileNumber">Mobile Number</label>
    <input
      type="text"
      className="form-control"
      id="mobileNumber"
      placeholder="Enter Mobile Number"
      onBlur={handleMobileChange}
    />
  </div>

  {/* DOB */}
  <div className="col-6 form-group">
    <label htmlFor="dob">Date of Birth (DOB)</label>
    <input type="date" className="form-control" id="dob" />
  </div>

  {/* DOM */}
  <div className="col-6 form-group">
    <label htmlFor="dom">Date of Marriage (DOM)</label>
    <input type="date" className="form-control" id="dom" />
  </div>

  {/* Email */}
  <div className="col-6 form-group">
    <label htmlFor="email">Email</label>
    <input
      type="email"
      className="form-control"
      id="email"
      placeholder="Enter Email"
      onBlur={handleEmailChange}
    />
  </div>

  {/* Account Number */}
  <div className="col-6 form-group">
    <label htmlFor="accountNumber">Account Number</label>
    <input
      type="text"
      className="form-control"
      id="accountNumber"
      placeholder="Enter Account Number"
    />
  </div>

  {/* IFSC Code */}
  <div className="col-6 form-group">
    <label htmlFor="ifscCode">IFSC Code</label>
    <input
      type="text"
      className="form-control"
      id="ifscCode"
      placeholder="Enter IFSC Code"
    />
  </div>

  {/* Bank Name */}
  <div className="col-6 form-group">
    <label htmlFor="bankName">Bank Name</label>
    <select className="form-control" id="bankName">
      <option value="bank1">Bank 1</option>
      <option value="bank2">Bank 2</option>
      <option value="bank3">Bank 3</option>
      <option value="bank4">Bank 4</option>
    </select>
  </div>

  {/* A/C @ Branch */}
  <div className="col-6 form-group">
    <label htmlFor="branch">A/C @ Branch</label>
    <input
      type="text"
      className="form-control"
      id="branch"
      placeholder="Enter Branch"
    />
  </div>

  {/* Managed By */}
  <div className="col-6 form-group">
    <label htmlFor="managedBy">Managed By</label>
    <input
      type="text"
      className="form-control"
      id="managedBy"
      placeholder="Enter Managed By"
    />
  </div>

  {/* Background */}
  <div className="col-6 form-group">
    <label htmlFor="background">Background</label>
    <input
      type="text"
      className="form-control"
      id="background"
      placeholder="Enter Background"
    />
  </div>

  {/* Incentive On Visit */}
  <div className="col-6 form-group">
    <label htmlFor="incentiveOnVisit">Incentive On Ref</label>
    <input
      type="text"
      className="form-control"
      id="incentiveOnVisit"
      placeholder="value"
    />
  </div>

  <div className="form-check mb-3">
                            <input
                              type="checkbox"
                              className="form-check-input"
                              id="percentage"
                            />
                            <label className="form-check-label" htmlFor="percentage">
                            In %
                            </label>
                          </div>

  </div>


                      </div>
                      <button type="submit" className="btn btn-gradient-primary me-2">Submit</button>
                      <button type="reset" className="btn btn-light">Cancel</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Reffby;
